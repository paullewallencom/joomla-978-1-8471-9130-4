<?php
defined( '_JEXEC' ) or die( 'Restricted access' );
echo '<div class="componentheading">Restaurant Reviews</div>';
?>