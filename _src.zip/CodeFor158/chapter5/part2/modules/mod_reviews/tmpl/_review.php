<?php defined('_JEXEC') or die('Restricted access'); ?>
<p><a href="<?php echo $link ?>"><?php echo $review->name; ?></a></p>
<p>"<?php echo $review->quicktake ?>"</p><p>&nbsp;</p>