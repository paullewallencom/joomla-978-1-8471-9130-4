INSERT INTO jos_plugins (name, element, folder, published) VALUES ('Content - Reviews', 'reviews', 'content', 1);
INSERT INTO jos_plugins (name, element, folder, published) VALUES ('Content - Review Information', 'reviewinfo', 'content', 0);
INSERT INTO jos_plugins (name, element, folder, published) VALUES ('Search - Reviews', 'reviews', 'search', 1);