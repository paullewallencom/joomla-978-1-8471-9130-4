DROP TABLE #__reviews;
DROP TABLE #__reviews_comments;