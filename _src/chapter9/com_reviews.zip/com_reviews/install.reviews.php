<?php

defined( '_JEXEC' ) or die( 'Restricted access' );

function com_install()
{
	?>
	<div class="header">Congratulations, Restaurant Reviews is ready to roll!</div>
	<p>
	Congratulations on not only purchasing, but also installing Restaurant Reviews! Undoubtedly, you are about to embark on many joyous hours of authoring and organizing all of the hot spots for your city. To get started, navigate to Components, Restaurant Reviews, Manage Reviews and click the "New" button at the right-hand corner of the screen. Also, be sure to install the accompanying plugins and module to promote your reviews throughout the website!
	</p>
	<?php
}

?>