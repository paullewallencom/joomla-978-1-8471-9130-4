<?php

defined( '_JEXEC' ) or die( 'Restricted access' );

function com_uninstall()
{
	?>
	<div class="header">The reviews are now removed from your system.</div>
	<p>
	We're sorry to see you go! To completely remove the software from your system, be sure to also uninstall the plugins and module.
	</p>
	<?php
}

?>