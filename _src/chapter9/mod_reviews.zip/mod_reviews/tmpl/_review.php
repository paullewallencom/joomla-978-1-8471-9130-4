<?php defined('_JEXEC') or die('Restricted access'); ?>
<a href="<?php echo $link ?>"><?php echo $review->name; ?></a><br />
<p>"<?php echo $review->quicktake ?>"</p><br />